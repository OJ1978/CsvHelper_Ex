﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CsvHelper;

namespace CSVHelper_Ex
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var reader = new StreamReader("Students.csv"))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = new List<Student>();
                csv.Read();
                csv.ReadHeader();
                while (csv.Read())
                {
                    var record = new Student
                    {
                        ID = csv.GetField<int>("ID"),
                        Name = csv.GetField("Name"),
                        Course = csv.GetField("Course")
                    };
                    records.Add(record);
                    Console.WriteLine(record.Name);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var records = new List<Student>
            {
                new Student { ID = 1, Name = "John", Course = "Excel" },
                new Student { ID = 2, Name = "Pete", Course = "Word" },
                new Student { ID = 3, Name = "Tom", Course = "Business" },
                new Student { ID = 4, Name = "Susan", Course = "Secretarial" },
                new Student { ID = 5, Name = "Monica", Course = "Graphics" },

            };

            using (var writer = new StreamWriter("Students_2.csv"))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.WriteRecords(records);
            }
        }
    }

    public class Student
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Course { get; set; }
    }
}
